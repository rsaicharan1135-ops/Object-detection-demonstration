# Object Detection Studio — Web Application

A Streamlit-based web app for demonstrating and comparing three pre-trained object-detection approaches:

- **YOLOv8n** — one-stage detector, generally designed for speed.
- **Faster R-CNN (ResNet50-FPN)** — two-stage detector.
- **SSD300 (VGG16)** — single-shot detector.

## Features

- Upload JPG, JPEG, PNG, or WEBP images.
- Select one or more detection algorithms.
- Adjust the confidence threshold.
- View annotated images with bounding boxes, labels, and confidence scores.
- View the number of detections and measured inference time.
- Compare selected methods on the same uploaded image.
- Download each annotated result.

## Run locally

Recommended: Python 3.10 or 3.11.

```bash
# 1. Create and activate a virtual environment (recommended)
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Start the web app
streamlit run app.py
```

Streamlit will print a local URL, normally `http://localhost:8501`.

## First-run model downloads

The app uses public pre-trained weights. The first time each algorithm is selected,
its weights may be downloaded automatically. This requires an internet connection
and can take several minutes. PyTorch uses CPU by default unless a compatible CUDA
installation is available.

## Important project notes

- This is an inference/demo application; it does **not** train a detector.
- No dataset is bundled. Upload an image to test the pre-trained models.
- Inference time is measured on the current computer and is not a universal benchmark.
- Do not report accuracy, precision, recall, or mAP from a single uploaded image.
  A proper evaluation requires a labelled test dataset and a defined evaluation protocol.
- The three model families may use different label sets and training datasets, so
  their outputs are not perfectly equivalent.

## Suggested project architecture

```text
object_detection_web_app/
├── app.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Suggested future extensions

1. Add batch image and video upload.
2. Add webcam/live-camera inference.
3. Add dataset evaluation with mAP, precision, recall, and confusion matrix.
4. Add model export (ONNX) and CPU/GPU selection.
5. Add user-defined class filtering and downloadable CSV reports.
