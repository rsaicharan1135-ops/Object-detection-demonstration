import io
import time
from typing import Dict, List, Tuple

import pandas as pd
import streamlit as st
from PIL import Image, ImageDraw, ImageFont

st.set_page_config(
    page_title="Object Detection Studio",
    page_icon="🔎",
    layout="wide",
)

ALGORITHMS = ["YOLOv8n", "Faster R-CNN", "SSD300"]
COLORS = {
    "YOLOv8n": (30, 136, 229),
    "Faster R-CNN": (0, 150, 136),
    "SSD300": (230, 126, 34),
}

st.markdown(
    """
    <style>
    .stApp { background: #f6f9fc; }
    .block-container { padding-top: 1.6rem; }
    .hero {
        padding: 1.35rem 1.6rem; border-radius: 16px;
        background: linear-gradient(110deg, #eaf3ff, #eefaf8);
        border: 1px solid #d9e7f4; margin-bottom: 1rem;
    }
    .hero h1 { color: #183b5b; margin: 0; }
    .hero p { color: #4d6478; margin: .35rem 0 0 0; }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="hero">
      <h1>Object Detection Studio</h1>
      <p>Upload an image, choose detection algorithms, and compare their predictions.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("Detection settings")
    selected_algorithms = st.multiselect(
        "Choose algorithms",
        ALGORITHMS,
        default=["YOLOv8n"],
        help="Choose one method or several to compare them on the same image.",
    )
    confidence = st.slider("Confidence threshold", 0.05, 0.95, 0.40, 0.05)
    st.caption("Higher thresholds show fewer, more confident detections.")
    st.divider()
    st.markdown("**Models used**")
    st.caption("YOLOv8n · Faster R-CNN ResNet50-FPN · SSD300 VGG16")
    st.caption("Pre-trained public weights are downloaded on first use.")

@st.cache_resource(show_spinner="Loading detection model…")
def load_model(algorithm: str):
    if algorithm == "YOLOv8n":
        from ultralytics import YOLO
        return YOLO("yolov8n.pt")
    import torch
    from torchvision.models.detection import (
        FasterRCNN_ResNet50_FPN_Weights,
        SSD300_VGG16_Weights,
        fasterrcnn_resnet50_fpn,
        ssd300_vgg16,
    )
    if algorithm == "Faster R-CNN":
        weights = FasterRCNN_ResNet50_FPN_Weights.DEFAULT
        model = fasterrcnn_resnet50_fpn(weights=weights)
        model.eval()
        return (model, weights.meta["categories"])
    if algorithm == "SSD300":
        weights = SSD300_VGG16_Weights.DEFAULT
        model = ssd300_vgg16(weights=weights)
        model.eval()
        return (model, weights.meta["categories"])
    raise ValueError(f"Unknown algorithm: {algorithm}")

def draw_detections(image: Image.Image, detections: List[Dict], algorithm: str) -> Image.Image:
    output = image.copy().convert("RGB")
    draw = ImageDraw.Draw(output)
    color = COLORS.get(algorithm, (30, 136, 229))
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", max(13, output.width // 65))
    except OSError:
        font = ImageFont.load_default()
    for item in detections:
        x1, y1, x2, y2 = item["box"]
        label = f'{item["label"]} {item["score"]:.2f}'
        draw.rectangle((x1, y1, x2, y2), outline=color, width=max(2, output.width // 350))
        text_box = draw.textbbox((x1, max(0, y1 - 22)), label, font=font)
        draw.rectangle(text_box, fill=color)
        draw.text((x1, max(0, y1 - 22)), label, fill="white", font=font)
    return output

def run_yolo(image: Image.Image, threshold: float) -> List[Dict]:
    model = load_model("YOLOv8n")
    result = model.predict(image, conf=threshold, verbose=False)[0]
    detections = []
    names = result.names
    if result.boxes is not None:
        for box in result.boxes:
            coords = box.xyxy[0].cpu().tolist()
            class_id = int(box.cls[0].cpu().item())
            score = float(box.conf[0].cpu().item())
            detections.append({
                "label": names[class_id],
                "score": score,
                "box": [float(v) for v in coords],
            })
    return detections

def run_torchvision(algorithm: str, image: Image.Image, threshold: float) -> List[Dict]:
    import torch
    from torchvision.transforms.functional import to_tensor

    model, categories = load_model(algorithm)
    tensor = to_tensor(image.convert("RGB"))
    with torch.inference_mode():
        prediction = model([tensor])[0]
    detections = []
    for box, label_id, score in zip(
        prediction["boxes"].cpu().tolist(),
        prediction["labels"].cpu().tolist(),
        prediction["scores"].cpu().tolist(),
    ):
        if float(score) >= threshold:
            label = categories[int(label_id)]
            if label != "__background__":
                detections.append({
                    "label": label,
                    "score": float(score),
                    "box": [float(v) for v in box],
                })
    return detections

def run_detection(algorithm: str, image: Image.Image, threshold: float):
    start = time.perf_counter()
    if algorithm == "YOLOv8n":
        detections = run_yolo(image, threshold)
    else:
        detections = run_torchvision(algorithm, image, threshold)
    elapsed = time.perf_counter() - start
    return detections, elapsed

uploaded = st.file_uploader(
    "Upload an image",
    type=["jpg", "jpeg", "png", "webp"],
    help="For best results, use a clear image with everyday objects.",
)

if uploaded is None:
    left, right = st.columns([1.15, 1])
    with left:
        st.subheader("How to use the application")
        st.markdown(
            "1. Upload a JPG, PNG, or WEBP image.  \n"
            "2. Select one or more detection algorithms in the sidebar.  \n"
            "3. Adjust the confidence threshold.  \n"
            "4. Click **Run detection** to view boxes, labels, scores, and timing."
        )
    with right:
        st.subheader("What you can compare")
        st.markdown(
            "- Detected object classes\n"
            "- Number of detections\n"
            "- Confidence scores\n"
            "- Inference time on this machine\n"
            "- Annotated output images"
        )
    st.info("No dataset is required for a first demonstration: upload any suitable image.")
    st.stop()

image = Image.open(uploaded).convert("RGB")
col1, col2 = st.columns([1.15, 1])
with col1:
    st.subheader("Input image")
    st.image(image, use_container_width=True)
with col2:
    st.subheader("Run configuration")
    st.write(f"**Image size:** {image.width} × {image.height} pixels")
    st.write(f"**Algorithms:** {', '.join(selected_algorithms) if selected_algorithms else 'None selected'}")
    st.write(f"**Confidence threshold:** {confidence:.2f}")
    run_button = st.button(
        "Run detection",
        type="primary",
        disabled=not selected_algorithms,
        use_container_width=True,
    )

if run_button:
    results = {}
    progress = st.progress(0, text="Preparing models…")
    errors = {}
    for index, algorithm in enumerate(selected_algorithms):
        try:
            with st.spinner(f"Running {algorithm}…"):
                detections, elapsed = run_detection(algorithm, image, confidence)
                annotated = draw_detections(image, detections, algorithm)
                results[algorithm] = {
                    "detections": detections,
                    "elapsed": elapsed,
                    "annotated": annotated,
                }
        except Exception as exc:
            errors[algorithm] = str(exc)
        progress.progress((index + 1) / len(selected_algorithms), text=f"Finished {algorithm}")
    progress.empty()
    st.session_state["results"] = results
    st.session_state["errors"] = errors
    st.session_state["source_name"] = uploaded.name

results = st.session_state.get("results", {})
errors = st.session_state.get("errors", {})

if errors:
    st.warning("Some algorithms could not run. Check the installation notes below.")
    for algorithm, message in errors.items():
        with st.expander(f"{algorithm} error"):
            st.code(message)

if results:
    st.divider()
    st.header("Detection results")
    summary = []
    tabs = st.tabs(list(results.keys()))
    for tab, (algorithm, data) in zip(tabs, results.items()):
        detections = data["detections"]
        with tab:
            image_col, details_col = st.columns([1.45, 1])
            with image_col:
                st.image(data["annotated"], caption=f"{algorithm} output", use_container_width=True)
                buffer = io.BytesIO()
                data["annotated"].save(buffer, format="PNG")
                st.download_button(
                    f"Download {algorithm} result",
                    data=buffer.getvalue(),
                    file_name=f"{algorithm.lower().replace(' ', '_').replace('-', '')}_detection.png",
                    mime="image/png",
                    key=f"download_{algorithm}",
                )
            with details_col:
                m1, m2 = st.columns(2)
                m1.metric("Objects detected", len(detections))
                m2.metric("Inference time", f"{data['elapsed']:.3f} s")
                if detections:
                    df = pd.DataFrame([
                        {"Object": d["label"], "Confidence": round(d["score"], 3)}
                        for d in detections
                    ])
                    st.dataframe(df, use_container_width=True, hide_index=True)
                else:
                    st.info("No objects passed the selected confidence threshold.")
        summary.append({
            "Algorithm": algorithm,
            "Objects detected": len(detections),
            "Inference time (s)": round(data["elapsed"], 4),
            "Mean confidence": round(
                sum(d["score"] for d in detections) / len(detections), 3
            ) if detections else 0,
        })

    st.divider()
    st.subheader("Algorithm comparison")
    comparison = pd.DataFrame(summary)
    st.dataframe(comparison, use_container_width=True, hide_index=True)
    if len(comparison) > 1:
        st.bar_chart(comparison.set_index("Algorithm")[["Inference time (s)"]])
    st.caption(
        "These are measurements from this run and this computer. They are not benchmark "
        "scores; speed depends on hardware, image size, model warm-up, and software versions."
    )

with st.expander("Installation and troubleshooting"):
    st.markdown(
        """
        **Requirements:** Python 3.10 or 3.11 is recommended.

        ```bash
        pip install -r requirements.txt
        streamlit run app.py
        ```

        The first run downloads pre-trained model weights and may take time. An internet
        connection is needed for the initial download. PyTorch may use CPU if CUDA is not
        available. If a model fails to load, check the error above and the PyTorch /
        torchvision installation for your operating system.
        """
    )

st.divider()
st.caption("Academic demonstration framework · Object Detection · YOLOv8n / Faster R-CNN / SSD300")
